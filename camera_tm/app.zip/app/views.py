from django.shortcuts import render
from django.utils.translation import gettext_lazy as _

def home(request):
    context = {
        'company_name': _('CameraTM'),
        'about_us_text': _('Welcome to CameraTM! We specialize in providing high-quality IP cameras and reliable home phone systems to meet your security and communication needs. Our mission is to offer innovative and user-friendly solutions with excellent customer support.'),
        'email': 'info@cameratm.com',
        'tiktok_link': 'https://www.tiktok.com/@camera.tm',
        'instagram_link': 'https://www.instagram.com/cameratm/',
        'linkedin_link': 'https://www.linkedin.com/company/cameratm',
        'imo_link': 'https://imo.im/c/CameraTM',
    }
    return render(request, 'home.html', context)