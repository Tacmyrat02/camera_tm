from django.db import models

class IPCamera(models.Model):
    model_name = models.CharField(max_length=255)
    features = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image = models.ImageField(upload_to='images/cameras/')  # You'll need to install Pillow for image handling

    def __str__(self):
        return self.model_name

class HomePhone(models.Model):
    model_name = models.CharField(max_length=255)
    features = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    num_handsets = models.IntegerField(default=1)
    image = models.ImageField(upload_to='images/phones/')  # You'll need to install Pillow for image handling

    def __str__(self):
        return self.model_name